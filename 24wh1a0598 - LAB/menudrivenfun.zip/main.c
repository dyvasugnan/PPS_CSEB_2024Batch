/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//menudrivenfunction
#include <stdio.h>
float circlearea(int r){
    return 3.14*r*r;
}
float rectarea(int l,int w){
    return l*w;
}
float triarea(int b,int h){
    return 0.5*b*h;
}
int main(){
    int r=3,h=6,l=5,w=2,b=4,choice1;
    float res;
    char choice2;
        printf("MENU \n 1.area of circle \n 2.area of rectangle \n 3.area of triangle \n 4.EXIT");
    do{
        printf("enter your choice");
        scanf("%d",&choice1);
        if(choice1<=3){
        switch(choice1){
            case 1 :
                res=circlearea(r);
                printf("%f",res);
                    break;
            case 2 :
                res=rectarea(l,w);
                printf("%f",res);
                    break;
             case 3 :
                res=triarea(b,h);
                printf("%f",res);
                    break;
        }
        printf("do you want to continue?");
        scanf(" %c",&choice2);
        }
        if(choice1==4){
            break;
        }
    }while(choice2!='n');    

    return 0;
}
